import { createPost } from './actions'

console.log(createPost('dan', 'New post'))
