export const CREATE_POST = 'CREATE_POST'
