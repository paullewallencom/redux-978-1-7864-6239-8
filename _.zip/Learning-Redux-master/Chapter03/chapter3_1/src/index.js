import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(
  <h1>hello world!</h1>,
  document.getElementById('root')
)
